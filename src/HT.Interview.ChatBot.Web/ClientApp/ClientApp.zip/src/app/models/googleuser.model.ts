export class GoogleUser {
  email: string;
  firstName: string;
  lastName: string;
  name: string;
  photoUrl: string;
  roleId: number;
  editMode: boolean;
}
