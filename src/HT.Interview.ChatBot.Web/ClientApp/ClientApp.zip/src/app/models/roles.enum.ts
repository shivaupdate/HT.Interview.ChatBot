export enum Roles{
    Admin=1,
    HumanResource=2,
    Candidate=3,
    Panelist=4
  }