export class Message {
  candidateId: string;
  sessionId: any;                    
  timeTaken: string;
  response: any;
  query: string;
  timestamp: Date;
  allocatedTime: string;
  remainingTime: string;
}
